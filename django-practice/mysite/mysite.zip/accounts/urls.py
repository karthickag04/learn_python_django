from django.urls import path

from . import views


app_name = "accounts"


urlpatterns = [
    path("login/", views.login_view, name="login"),
    path("register/", views.register_view, name="register"),
    path(
        "change-password/",
        views.change_password_view,
        name="change_password",
    ),
]